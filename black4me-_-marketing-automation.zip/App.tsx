import React, { useState, useEffect } from 'react';
import InputSection from './components/InputSection';
import ResultsView from './components/ResultsView';
import { generateMarketingPlan } from './services/geminiService';
import { MarketingPlan, MarketingInput, UserData, StaffData, Language } from './types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell
} from 'recharts';
import { 
  LayoutDashboard, 
  Zap, 
  Database, 
  Home, 
  Users, 
  Mail, 
  Check, 
  LogOut, 
  MessageCircle, 
  Settings, 
  Phone,
  Download,
  Share2,
  Lock,
  Loader2,
  X,
  User,
  ArrowLeft,
  CalendarCheck,
  Crown,
  Filter,
  Activity,
  FileSpreadsheet,
  AlertCircle,
  ShieldAlert,
  Plus,
  Trash2,
  Clock,
  RefreshCw,
  Search,
  Globe,
  UserCheck,
  Briefcase,
  Ban,
  Sliders,
  Calendar,
  KeyRound,
  LogIn,
  Wand2
} from 'lucide-react';

// --- Constants & Translations ---
const ADMIN_PASSWORD = "Stylesg1995";

const translations = {
  ar: {
    brandName: "BLACK4ME",
    slogan: "التسويق الآلي الذكي",
    homeTitle: "بوابة العملاء",
    homeSubtitle: "نظام إدارة التسويق",
    homeDesc: "المنصة حصرية للأعضاء المسجلين. يرجى تسجيل الدخول للوصول إلى لوحة التحكم.",
    emailPlaceholder: "البريد الإلكتروني...",
    startNow: "دخول الأعضاء",
    navHome: "الرئيسية",
    navDashboard: "توليد المحتوى",
    navAdmin: "الإدارة",
    navSettings: "الإعدادات",
    navProfile: "الحساب",
    navLogout: "خروج",
    welcomeUser: "🌟 أهلاً بك {name}! تسجيل دخول ناجح",
    subActive: "الباقة: {plan} | الصلاحية: {date}",
    daysLeft: "{days} يوم متبقي",
    expired: "منتهي",
    active: "نشط",
    profileTitle: "بيانات الحساب",
    name: "الاسم",
    email: "البريد الإلكتروني",
    country: "الدولة",
    phone: "رقم الهاتف",
    plan: "نوع الاشتراك",
    duration: "المدة المتبقية",
    whatsappSupport: "تواصل مع الدعم الفني",
    adminLogin: "دخول المدير",
    password: "كلمة المرور",
    accessDenied: "غير مصرح بالدخول",
    bannedMessage: "⛔ عذراً، هذا الحساب منتهي الصلاحية أو غير نشط. يرجى التواصل مع الإدارة لتجديد الاشتراك.",
    userNotFound: "عذراً، بيانات الدخول غير صحيحة.",
    staffManagement: "إدارة الموظفين",
    addStaff: "إضافة موظف",
    customers: "العملاء",
    analytics: "التحليلات",
    addUser: "إضافة عميل",
    extend: "تمديد",
    delete: "حذف",
    loading: "جاري التحميل...",
    generating: "جاري توليد الخطة...",
    errorGen: "حدث خطأ أثناء التوليد",
    trial: "تجربة مجانية",
    monthly: "شهري",
    yearly: "سنوي",
    searchPlaceholder: "بحث...",
    price: "المبلغ",
    actions: "إجراءات",
    staffPassword: "كلمة المرور للموظف",
    clientPassword: "كلمة المرور للعميل",
    login: "تسجيل الدخول",
    back: "عودة",
    renewConfirm: "تجديد الاشتراك لمدة 30 يوم؟",
    banConfirm: "هل أنت متأكد؟ سيتم حظر البريد الإلكتروني وحذف العميل.",
    fromMuscat: "🇴🇲 من مسقط إلى العالم",
    feat1: "تحكم في حملاتك التسويقية",
    feat2: "جدول منشوراتك",
    feat3: "أنشئ محتوى احترافي بضغطة زر",
    generate: "توليد",
    userCreated: "✅ تم إنشاء الحساب بنجاح!\n\nالبيانات للدخول:\nالبريد: {email}\nكلمة المرور: {pass}\n\nيرجى نسخها وإرسالها للعميل.",
    
    // Input Section
    inputTitle: "بيانات المنتج",
    inputSubtitle: "أدخل تفاصيل منتجك وسنقوم بتوليد المحتوى بالكامل",
    prodName: "اسم المنتج (إجباري)",
    prodNamePlace: "مثال: متجر العطور الفاخرة",
    platformType: "نوع المنصة",
    pt_store: "متجر إلكتروني (سلة/زد/Shopify)",
    pt_landing: "صفحة هبوط",
    pt_blog: "مدونة / محتوى",
    pt_social: "حساب تواصل اجتماعي",
    pt_service: "خدمة رقمية",
    prodLink: "رابط المنتج",
    prodDesc: "وصف المنتج (إجباري)",
    prodDescPlace: "اكتب وصفاً دقيقاً للمنتج. مثال: عطور زيتية فرنسية أصلية بأسعار منافسة، نستهدف الشباب في الخليج...",
    discountCode: "كود الخصم",
    discountVal: "قيمة الخصم",
    launchBtn: "إطلاق الحملة الآن",
    genBtn: "جاري توليد الخطة (Gemini AI)...",

    // Results View - Dashboard
    dashboardTitle: "لوحة التحكم بالحملة",
    dashboardSubtitle: "إدارة، جدولة، ونشر المحتوى.",
    printBtn: "PDF / طباعة",
    excelBtn: "Excel تصدير",
    
    // Tabs
    tabDrafts: "المسودات (Social)",
    tabSchedule: "الجدول الزمني",
    tabSystem: "رسائل النظام",
    tabSales: "حملة المبيعات",
    tabHeadlines: "العناوين",
    tabDescriptions: "الوصف",
    tabAds: "الإعلانات",
    
    // Social & Schedule
    connectTitle: "ربط المنصات",
    connectDesc: "انقر على أيقونة المنصة لتفعيل النشر عليها",
    selectedPlatforms: "تم اختيار {count} منصة",
    moveToSchedule: "نقل إلى الجدول الزمني",
    draftLabel: "مسودة",
    pubDate: "تاريخ النشر",
    pubTime: "وقت النشر",
    visualIdea: "اقتراح بصري:",
    scheduleTitle: "جدول النشر (عرض القائمة)",
    scheduleDesc: "هذه القائمة تمثل قاعدة بيانات المنصة للمحتوى المجدول.",
    scheduleEmpty: "الجدول فارغ",
    scheduleEmptyDesc: "قم بالعودة لتبويب المسودات لاختيار المنشورات ونقلها هنا.",
    thPlatform: "المنصة",
    thDateTime: "التاريخ / الوقت",
    thContent: "المحتوى",
    thStatus: "الحالة",
    thActions: "إجراءات",
    statusPublished: "تم النشر",
    statusScheduled: "مجدول",
    
    // Emails & Content
    sysEmailTitle: "رسائل النظام الآلية",
    sysEmailDesc: "يتم إرسال هذه الرسائل تلقائياً للمشتركين بناءً على حالة اشتراكهم.",
    sendTime: "وقت الإرسال:",
    subject: "الموضوع:",
    preview: "تمهيد",
    adLabel: "إعلان",
    keywords: "الكلمات المفتاحية",

    // Alerts
    alertSchedule: "✅ تمت جدولة {count} منشور بنجاح!",
    alertNoPlatform: "⚠️ تنبيه: يرجى ربط حساب منصة واحدة على الأقل.",
    alertNoPosts: "⚠️ لا توجد منشورات تتطابق مع المنصات المتصلة.",
    confirmDelete: "هل أنت متأكد من حذف هذا المنشور؟",
    publishedSuccess: "تم النشر بنجاح! 🚀"
  },
  en: {
    brandName: "BLACK4ME",
    slogan: "Smart Marketing Automation",
    homeTitle: "Client Portal",
    homeSubtitle: "Marketing Management System",
    homeDesc: "This platform is exclusive to registered members. Please login to access the dashboard.",
    emailPlaceholder: "Email Address...",
    startNow: "Member Login",
    navHome: "Home",
    navDashboard: "Content Gen",
    navAdmin: "Admin",
    navSettings: "Settings",
    navProfile: "Account",
    navLogout: "Logout",
    welcomeUser: "🌟 Welcome back {name}!",
    subActive: "Plan: {plan} | Valid until: {date}",
    daysLeft: "{days} days left",
    expired: "Expired",
    active: "Active",
    profileTitle: "Account Details",
    name: "Name",
    email: "Email",
    country: "Country",
    phone: "Phone Number",
    plan: "Subscription Plan",
    duration: "Time Remaining",
    whatsappSupport: "Contact Support",
    adminLogin: "Admin Login",
    password: "Password",
    accessDenied: "Access Denied",
    bannedMessage: "⛔ Sorry, this account is expired or inactive. Please contact administration to renew.",
    userNotFound: "Invalid email or password.",
    staffManagement: "Staff Management",
    addStaff: "Add Staff",
    customers: "Customers",
    analytics: "Analytics",
    addUser: "Add Customer",
    extend: "Extend",
    delete: "Delete",
    loading: "Loading...",
    generating: "Generating Plan...",
    errorGen: "Error generating plan",
    trial: "Free Trial",
    monthly: "Monthly",
    yearly: "Yearly",
    searchPlaceholder: "Search...",
    price: "Price",
    actions: "Actions",
    staffPassword: "Staff Password",
    clientPassword: "Client Password",
    login: "Login",
    back: "Back",
    renewConfirm: "Renew subscription for 30 days?",
    banConfirm: "Are you sure? Email will be banned and user removed.",
    fromMuscat: "🇴🇲 From Muscat to the World",
    feat1: "Control Your Marketing",
    feat2: "Schedule Your Posts",
    feat3: "Create Professional Content with One Click",
    generate: "Generate",
    userCreated: "✅ Account Created Successfully!\n\nLogin Details:\nEmail: {email}\nPassword: {pass}\n\nPlease copy and share with the client.",
    
    // Input Section
    inputTitle: "Product Details",
    inputSubtitle: "Enter product details and we will generate full content",
    prodName: "Product Name (Required)",
    prodNamePlace: "Ex: Luxury Perfume Store",
    platformType: "Platform Type",
    pt_store: "E-commerce Store (Shopify/Salla)",
    pt_landing: "Landing Page",
    pt_blog: "Blog / Content",
    pt_social: "Social Media Account",
    pt_service: "Digital Service",
    prodLink: "Product Link",
    prodDesc: "Product Description (Required)",
    prodDescPlace: "Write a detailed description. Ex: Original French oil perfumes competitive prices...",
    discountCode: "Discount Code",
    discountVal: "Discount Value",
    launchBtn: "Launch Campaign Now",
    genBtn: "Generating Plan (Gemini AI)...",

    // Results View - Dashboard
    dashboardTitle: "Campaign Dashboard",
    dashboardSubtitle: "Manage, schedule, and publish content.",
    printBtn: "PDF / Print",
    excelBtn: "Export Excel",
    
    // Tabs
    tabDrafts: "Drafts (Social)",
    tabSchedule: "Schedule",
    tabSystem: "System Emails",
    tabSales: "Sales Campaign",
    tabHeadlines: "Headlines",
    tabDescriptions: "Descriptions",
    tabAds: "Ads",
    
    // Social & Schedule
    connectTitle: "Connect Platforms",
    connectDesc: "Click platform icon to enable publishing",
    selectedPlatforms: "{count} platforms selected",
    moveToSchedule: "Move to Schedule",
    draftLabel: "Draft",
    pubDate: "Publish Date",
    pubTime: "Publish Time",
    visualIdea: "Visual Idea:",
    scheduleTitle: "Publishing Schedule (List View)",
    scheduleDesc: "This list represents the platform database for scheduled content.",
    scheduleEmpty: "Schedule Empty",
    scheduleEmptyDesc: "Go back to Drafts tab to select and move posts here.",
    thPlatform: "Platform",
    thDateTime: "Date / Time",
    thContent: "Content",
    thStatus: "Status",
    thActions: "Actions",
    statusPublished: "Published",
    statusScheduled: "Scheduled",
    
    // Emails & Content
    sysEmailTitle: "Automated System Emails",
    sysEmailDesc: "These emails are sent automatically based on subscription status.",
    sendTime: "Send Time:",
    subject: "Subject:",
    preview: "Preview",
    adLabel: "Ad",
    keywords: "Keywords",

    // Alerts
    alertSchedule: "✅ Successfully scheduled {count} posts!",
    alertNoPlatform: "⚠️ Alert: Please connect at least one platform.",
    alertNoPosts: "⚠️ No posts match the connected platforms.",
    confirmDelete: "Are you sure you want to delete this post?",
    publishedSuccess: "Published successfully! 🚀"
  }
};

const INITIAL_USERS: UserData[] = [
  {
    id: 'USR-1001',
    name: 'Jassim Mohammed',
    email: 'info@black4me.com',
    password: '123', // Default password for testing
    country: 'Oman',
    phone: '+968 7919 1793',
    joinDate: '2023-01-01',
    plan: 'Yearly',
    price: '$0',
    status: 'Active',
    subscriptionEndDate: '2030-12-31'
  }
];

const ANALYTICS_DATA = [
  { name: 'Jan', subscribers: 400, revenue: 2400 },
  { name: 'Feb', subscribers: 300, revenue: 1398 },
  { name: 'Mar', subscribers: 200, revenue: 9800 },
];

const PIE_DATA = [
  { name: 'Active', value: 400, color: '#22c55e' },
  { name: 'Expired', value: 100, color: '#ef4444' },
  { name: 'Trial', value: 300, color: '#D4AF37' },
];

// --- Helper Functions ---
const formatDate = (dateString: string, locale: 'ar' | 'en') => {
  try {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(locale === 'ar' ? 'ar-OM' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  } catch (e) {
    return dateString;
  }
};

const generateRandomPassword = () => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'; // Removed confusing chars like I, l, 1, O, 0
  let pass = '';
  for (let i = 0; i < 8; i++) {
    pass += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return pass;
};

// --- Helper Components ---
const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-brand-surface border border-white/10 rounded-xl w-full max-w-2xl max-h-[80vh] overflow-y-auto shadow-2xl relative">
        <div className="p-6 border-b border-white/10 flex justify-between items-center sticky top-0 bg-brand-surface z-10">
          <h3 className="text-xl font-bold text-white">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>
        <div className="p-6 text-gray-300 leading-relaxed whitespace-pre-wrap">
          {children}
        </div>
      </div>
    </div>
  );
};

// --- Page Components ---

const UserProfile = ({ user, lang, t }: { user: UserData, lang: Language, t: any }) => {
  const calculateDaysRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const today = new Date();
    const diffTime = end.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysLeft = calculateDaysRemaining(user.subscriptionEndDate);

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4">
       <div className="bg-brand-surface border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
          <div className="bg-gradient-to-r from-brand-gold to-yellow-600 p-6 flex justify-between items-center text-black">
             <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-black/20 rounded-full flex items-center justify-center text-black backdrop-blur-sm">
                   <User size={32} />
                </div>
                <div>
                   <h2 className="text-2xl font-bold">{user.name}</h2>
                   <p className="opacity-80 text-sm font-mono">{user.id}</p>
                </div>
             </div>
             <div className="text-center bg-black/10 px-4 py-2 rounded-lg backdrop-blur-sm">
                <span className="block text-xs font-bold uppercase mb-1">{t.status || "Status"}</span>
                <span className="font-bold text-lg">{daysLeft > 0 ? t.active : t.expired}</span>
             </div>
          </div>
          
          <div className="p-8 grid md:grid-cols-2 gap-8">
             <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-black/30 rounded border border-white/5">
                   <Mail className="text-brand-gold" size={20} />
                   <div>
                      <span className="text-xs text-gray-500 block">{t.email}</span>
                      <span className="text-white">{user.email}</span>
                   </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-black/30 rounded border border-white/5">
                   <Phone className="text-brand-gold" size={20} />
                   <div>
                      <span className="text-xs text-gray-500 block">{t.phone}</span>
                      <span className="text-white" dir="ltr">{user.phone || "N/A"}</span>
                   </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-black/30 rounded border border-white/5">
                   <Globe className="text-brand-gold" size={20} />
                   <div>
                      <span className="text-xs text-gray-500 block">{t.country}</span>
                      <span className="text-white">{user.country}</span>
                   </div>
                </div>
             </div>

             <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-black/30 rounded border border-white/5">
                   <Crown className="text-brand-gold" size={20} />
                   <div>
                      <span className="text-xs text-gray-500 block">{t.plan}</span>
                      <span className="text-white">{user.plan}</span>
                   </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-black/30 rounded border border-white/5">
                   <Clock className="text-brand-gold" size={20} />
                   <div>
                      <span className="text-xs text-gray-500 block">{t.duration}</span>
                      <span className={`font-bold ${daysLeft > 7 ? 'text-green-400' : 'text-red-400'}`}>
                         {daysLeft > 0 ? `${daysLeft} days` : t.expired} ({formatDate(user.subscriptionEndDate, lang)})
                      </span>
                   </div>
                </div>
                
                <a 
                   href="https://wa.me/message/WSGFIIEB3VZIH1" 
                   target="_blank" 
                   rel="noreferrer"
                   className="flex items-center justify-center gap-2 w-full bg-green-600 text-white font-bold py-3 rounded hover:bg-green-500 transition shadow-lg shadow-green-900/20"
                >
                   <MessageCircle size={20} /> {t.whatsappSupport}
                </a>
             </div>
          </div>
       </div>
    </div>
  );
};

const AdminLogin = ({ onLogin, t }: { onLogin: (pass: string) => void, t: any }) => {
  const [pass, setPass] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pass === ADMIN_PASSWORD) {
      onLogin(pass);
    } else {
      setError(true);
    }
  };

  return (
    <div className="flex items-center justify-center h-[60vh] animate-in zoom-in">
       <div className="bg-brand-surface p-8 rounded-2xl border border-white/10 shadow-2xl w-full max-w-md">
          <div className="text-center mb-6">
             <div className="w-16 h-16 bg-brand-gold/10 rounded-full flex items-center justify-center mx-auto mb-4 text-brand-gold">
                <Lock size={32} />
             </div>
             <h2 className="text-2xl font-bold text-white">{t.adminLogin}</h2>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
             <div>
               <label className="text-sm text-gray-400 mb-1 block">{t.password}</label>
               <input 
                 autoFocus
                 type="password" 
                 value={pass}
                 onChange={e => {setPass(e.target.value); setError(false)}}
                 className="w-full bg-black border border-white/20 rounded-lg px-4 py-3 text-white focus:border-brand-gold outline-none"
               />
             </div>
             {error && <p className="text-red-500 text-sm text-center">كلمة المرور غير صحيحة</p>}
             <button type="submit" className="w-full bg-brand-gold text-black font-bold py-3 rounded-lg hover:bg-white transition">
               {t.adminLogin}
             </button>
          </form>
       </div>
    </div>
  );
};

const AdminDashboard = ({ 
  users,
  staffList,
  onAddUser,
  onExtendUser,
  onDeleteUser,
  onAddStaff,
  onRemoveStaff,
  t,
  lang
}: { 
  users: UserData[],
  staffList: StaffData[],
  onAddUser: (user: Omit<UserData, 'id' | 'joinDate' | 'status' | 'subscriptionEndDate'>) => void,
  onExtendUser: (id: string) => void,
  onDeleteUser: (id: string) => void,
  onAddStaff: (email: string, password: string) => void,
  onRemoveStaff: (id: string) => void,
  t: any,
  lang: Language
}) => {
  const [activeTab, setActiveTab] = useState<'users' | 'analytics' | 'staff'>('users');
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', country: '', phone: '', plan: 'Monthly' as const, price: '' });
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [newStaffPassword, setNewStaffPassword] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const calculateDaysRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const today = new Date();
    const diffTime = end.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Auto generate password if empty
    const finalPassword = newUser.password || generateRandomPassword();
    const userToAdd = { ...newUser, password: finalPassword };
    
    onAddUser(userToAdd);

    // Show credentials to admin
    const alertMsg = t.userCreated
      .replace('{email}', userToAdd.email)
      .replace('{pass}', finalPassword);
    
    alert(alertMsg);

    setNewUser({ name: '', email: '', password: '', country: '', phone: '', plan: 'Monthly', price: '' });
  };

  const handleStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(newStaffEmail && newStaffPassword) {
      onAddStaff(newStaffEmail, newStaffPassword);
      setNewStaffEmail('');
      setNewStaffPassword('');
    }
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">{t.navAdmin}</h2>
        <div className="flex gap-2">
           <button 
             onClick={() => setActiveTab('users')} 
             className={`px-4 py-2 rounded-lg font-bold transition ${activeTab === 'users' ? 'bg-brand-gold text-black' : 'bg-brand-surface text-gray-400'}`}
           >
             <Users size={18} className={`inline ${lang === 'ar' ? 'ml-2' : 'mr-2'}`}/> {t.customers}
           </button>
           <button 
             onClick={() => setActiveTab('staff')} 
             className={`px-4 py-2 rounded-lg font-bold transition ${activeTab === 'staff' ? 'bg-brand-gold text-black' : 'bg-brand-surface text-gray-400'}`}
           >
             <Briefcase size={18} className={`inline ${lang === 'ar' ? 'ml-2' : 'mr-2'}`}/> {t.staffManagement}
           </button>
           <button 
             onClick={() => setActiveTab('analytics')} 
             className={`px-4 py-2 rounded-lg font-bold transition ${activeTab === 'analytics' ? 'bg-brand-gold text-black' : 'bg-brand-surface text-gray-400'}`}
           >
             <Activity size={18} className={`inline ${lang === 'ar' ? 'ml-2' : 'mr-2'}`}/> {t.analytics}
           </button>
        </div>
      </div>

      {activeTab === 'staff' && (
        <div className="space-y-8">
           <div className="bg-brand-surface border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><UserCheck size={20} className="text-brand-gold"/> {t.addStaff}</h3>
              <form onSubmit={handleStaffSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                 <div>
                    <label className="text-xs text-gray-500 mb-1 block">{t.email}</label>
                    <input required type="email" value={newStaffEmail} onChange={e => setNewStaffEmail(e.target.value)} className="w-full bg-black border border-white/10 rounded p-2 text-white text-sm" />
                 </div>
                 <div>
                    <label className="text-xs text-gray-500 mb-1 block">{t.staffPassword}</label>
                    <input required type="text" value={newStaffPassword} onChange={e => setNewStaffPassword(e.target.value)} className="w-full bg-black border border-white/10 rounded p-2 text-white text-sm" />
                 </div>
                 <button type="submit" className="bg-green-600 text-white font-bold py-2 px-6 rounded hover:bg-green-500 h-[38px]">{t.addStaff}</button>
              </form>
           </div>

           <div className="bg-brand-surface border border-white/10 rounded-xl overflow-hidden max-w-4xl">
              <div className="p-4 border-b border-white/10 bg-black/20">
                 <h3 className="font-bold text-white">{t.staffManagement} ({staffList.length})</h3>
              </div>
              <div className="p-4 space-y-2">
                 {staffList.map(staff => (
                   <div key={staff.id} className="flex justify-between items-center bg-black/40 p-3 rounded border border-white/5">
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 rounded-full bg-brand-gold/20 flex items-center justify-center text-brand-gold">
                            {staff.role === 'Admin' ? <Lock size={14}/> : <UserCheck size={14}/>}
                         </div>
                         <div>
                            <p className="text-white text-sm font-bold">{staff.email}</p>
                            <p className="text-xs text-gray-500 flex gap-2">
                               <span>{staff.role}</span>
                               {staff.password && <span className="text-gray-600">Pass: {staff.password}</span>}
                            </p>
                         </div>
                      </div>
                      {staff.role !== 'Admin' && (
                        <button onClick={() => onRemoveStaff(staff.id)} className="text-red-400 hover:text-red-300 p-2"><Trash2 size={16}/></button>
                      )}
                   </div>
                 ))}
              </div>
           </div>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="space-y-8">
           {/* Add User Form */}
           <div className="bg-brand-surface border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><Plus size={20} className="text-brand-gold"/> {t.addUser}</h3>
              <form onSubmit={handleAddSubmit} className="grid grid-cols-1 md:grid-cols-6 gap-4 items-end">
                 <div>
                    <label className="text-xs text-gray-500 mb-1 block">{t.name}</label>
                    <input required type="text" value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} className="w-full bg-black border border-white/10 rounded p-2 text-white text-sm" />
                 </div>
                 <div>
                    <label className="text-xs text-gray-500 mb-1 block">{t.email}</label>
                    <input required type="email" value={newUser.email} onChange={e => setNewUser({...newUser, email: e.target.value})} className="w-full bg-black border border-white/10 rounded p-2 text-white text-sm" />
                 </div>
                 <div className="relative">
                    <label className="text-xs text-gray-500 mb-1 block">{t.password}</label>
                    <input 
                      type="text" 
                      value={newUser.password} 
                      onChange={e => setNewUser({...newUser, password: e.target.value})} 
                      className="w-full bg-black border border-white/10 rounded p-2 text-white text-sm pl-8" 
                      placeholder={lang === 'ar' ? 'تلقائي' : 'Auto'}
                    />
                    <button 
                      type="button" 
                      onClick={() => setNewUser({...newUser, password: generateRandomPassword()})}
                      className={`absolute bottom-2 ${lang === 'ar' ? 'left-2' : 'right-2'} text-brand-gold hover:text-white transition`}
                      title={t.generate}
                    >
                      <Wand2 size={14} />
                    </button>
                 </div>
                 <div>
                    <label className="text-xs text-gray-500 mb-1 block">{t.phone}</label>
                    <input type="tel" value={newUser.phone} onChange={e => setNewUser({...newUser, phone: e.target.value})} className="w-full bg-black border border-white/10 rounded p-2 text-white text-sm" />
                 </div>
                 <div>
                    <label className="text-xs text-gray-500 mb-1 block">{t.price}</label>
                    <input type="text" value={newUser.price} onChange={e => setNewUser({...newUser, price: e.target.value})} className="w-full bg-black border border-white/10 rounded p-2 text-white text-sm" />
                 </div>
                 <button type="submit" className="bg-green-600 text-white font-bold py-2 rounded hover:bg-green-500 h-[38px]">{t.addUser}</button>
              </form>
           </div>

           {/* Users Table */}
           <div className="bg-brand-surface border border-white/10 rounded-xl overflow-hidden pb-12">
              <div className="p-4 border-b border-white/10 flex justify-between items-center bg-black/20">
                 <h3 className="font-bold text-white">{t.customers} ({filteredUsers.length})</h3>
                 <div className="relative">
                    <Search className={`absolute ${lang === 'ar' ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 text-gray-500`} size={14} />
                    <input 
                      type="text" 
                      placeholder={t.searchPlaceholder} 
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      className={`bg-black border border-white/10 rounded-full ${lang === 'ar' ? 'pr-8 pl-4' : 'pl-8 pr-4'} py-1.5 text-sm text-white w-64 focus:border-brand-gold outline-none`}
                    />
                 </div>
              </div>
              <div className="overflow-x-auto">
                <table className={`w-full text-sm ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                  <thead className="bg-brand-black text-xs text-gray-400 uppercase">
                    <tr>
                      <th className="px-6 py-4">ID</th>
                      <th className="px-6 py-4">{t.name}</th>
                      <th className="px-6 py-4">{t.country}</th>
                      <th className="px-6 py-4">{t.price}</th>
                      <th className="px-6 py-4">{t.duration}</th>
                      <th className="px-6 py-4">{t.actions}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {filteredUsers.map((user) => {
                      const daysLeft = calculateDaysRemaining(user.subscriptionEndDate);
                      return (
                        <tr key={user.id} className="hover:bg-white/5 transition">
                          <td className="px-6 py-4 text-gray-500 font-mono text-xs">{user.id}</td>
                          <td className="px-6 py-4">
                             <div className="font-bold text-white">{user.name}</div>
                             <div className="text-xs text-gray-500">{user.email}</div>
                             {user.password && <div className="text-[10px] text-gray-600 mt-1 font-mono bg-black/30 inline-block px-1 rounded">Pass: {user.password}</div>}
                          </td>
                          <td className="px-6 py-4 text-gray-300">{user.country}</td>
                          <td className="px-6 py-4 text-brand-gold font-mono">{user.price}</td>
                          <td className="px-6 py-4">
                             <span className={`flex items-center gap-1 font-bold ${daysLeft > 7 ? 'text-green-400' : daysLeft > 0 ? 'text-yellow-400' : 'text-red-400'}`}>
                               <Clock size={14}/> {daysLeft > 0 ? `${daysLeft} days` : t.expired}
                             </span>
                          </td>
                          <td className="px-6 py-4">
                             <div className="flex items-center gap-3">
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if(window.confirm(t.renewConfirm)) {
                                      onExtendUser(user.id);
                                    }
                                  }}
                                  title={t.extend}
                                  className="group flex items-center gap-2 bg-blue-500/10 text-blue-400 px-3 py-2 rounded-lg hover:bg-blue-500/20 border border-blue-500/20 transition-all hover:scale-105 active:scale-95"
                                >
                                  <RefreshCw size={16} className="group-hover:rotate-180 transition-transform duration-500" />
                                  <span className="text-xs font-bold">{lang === 'ar' ? 'تجديد' : 'Renew'}</span>
                                </button>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onDeleteUser(user.id);
                                  }}
                                  title={t.delete}
                                  className="group flex items-center gap-2 bg-red-500/10 text-red-400 px-3 py-2 rounded-lg hover:bg-red-500/20 border border-red-500/20 transition-all hover:scale-105 active:scale-95"
                                >
                                  <Trash2 size={16} />
                                  <span className="text-xs font-bold">{lang === 'ar' ? 'حظر' : 'Ban'}</span>
                                </button>
                             </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'analytics' && (
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-brand-surface p-6 rounded-xl border border-white/5 w-full h-96">
               <h3 className="text-white font-bold mb-4">Growth</h3>
               <ResponsiveContainer width="100%" height="100%">
                 <BarChart data={ANALYTICS_DATA}>
                   <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                   <XAxis dataKey="name" stroke="#666" />
                   <YAxis stroke="#666" />
                   <Tooltip contentStyle={{backgroundColor: '#000', border: '1px solid #333'}} />
                   <Bar dataKey="subscribers" fill="#D4AF37" />
                 </BarChart>
               </ResponsiveContainer>
            </div>
            <div className="bg-brand-surface p-6 rounded-xl border border-white/5 w-full h-96">
               <h3 className="text-white font-bold mb-4">Status</h3>
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                   <Pie data={PIE_DATA} dataKey="value" cx="50%" cy="50%" innerRadius={60} outerRadius={100}>
                     {PIE_DATA.map((entry, index) => <Cell key={index} fill={entry.color} />)}
                   </Pie>
                   <Tooltip contentStyle={{backgroundColor: '#000', border: '1px solid #333'}} />
                   <Legend />
                 </PieChart>
               </ResponsiveContainer>
            </div>
         </div>
      )}
    </div>
  );
};

// --- HomePage Component ---
const HomePage = ({ 
  onLogin,
  t,
  lang
}: { 
  onLogin: (email: string, password?: string) => void,
  t: any,
  lang: Language
}) => {
  const [showLogin, setShowLogin] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(email && password) {
       onLogin(email, password);
    }
  };

  if (showLogin) {
    return (
      <div className="flex items-center justify-center min-h-[60vh] animate-in zoom-in">
         <div className="bg-brand-surface p-8 rounded-2xl border border-white/10 shadow-2xl w-full max-w-md relative">
            <button 
              onClick={() => setShowLogin(false)}
              className="absolute top-4 left-4 text-gray-500 hover:text-white"
            >
              <ArrowLeft size={20} />
            </button>
            <div className="text-center mb-6">
               <div className="w-16 h-16 bg-brand-gold/10 rounded-full flex items-center justify-center mx-auto mb-4 text-brand-gold">
                  <User size={32} />
               </div>
               <h2 className="text-2xl font-bold text-white">{t.startNow}</h2>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
               <div>
                 <label className="text-sm text-gray-400 mb-1 block">{t.email}</label>
                 <input 
                   autoFocus
                   type="email" 
                   value={email}
                   onChange={e => setEmail(e.target.value)}
                   className="w-full bg-black border border-white/20 rounded-lg px-4 py-3 text-white focus:border-brand-gold outline-none"
                   required
                 />
               </div>
               <div>
                 <label className="text-sm text-gray-400 mb-1 block">{t.password}</label>
                 <input 
                   type="password" 
                   value={password}
                   onChange={e => setPassword(e.target.value)}
                   className="w-full bg-black border border-white/20 rounded-lg px-4 py-3 text-white focus:border-brand-gold outline-none"
                   required
                 />
               </div>
               <button type="submit" className="w-full bg-brand-gold text-black font-bold py-3 rounded-lg hover:bg-white transition flex items-center justify-center gap-2">
                 {t.login} <LogIn size={18} />
               </button>
            </form>
         </div>
      </div>
    );
  }

  return (
    <div className="text-center animate-in fade-in zoom-in duration-700 py-12 md:py-20">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="inline-flex items-center gap-2 bg-brand-surface border border-brand-gold/30 rounded-full px-4 py-1 text-sm text-brand-gold mb-4">
          <Zap size={14} /> {t.homeSubtitle}
        </div>
        
        <h1 className="text-5xl md:text-7xl font-extrabold text-white leading-tight">
           {t.brandName} <br />
           <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-yellow-200">{t.slogan}</span>
        </h1>

        <p className="text-lg text-brand-gold font-medium">{t.fromMuscat}</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto my-12">
           <div className="bg-white/5 border border-white/10 p-6 rounded-xl flex flex-col items-center gap-4 hover:bg-white/10 transition group">
              <div className="w-16 h-16 bg-brand-gold/10 rounded-full flex items-center justify-center text-brand-gold group-hover:scale-110 transition-transform">
                 <Sliders size={32} />
              </div>
              <h3 className="font-bold text-white text-lg">{t.feat1}</h3>
           </div>
           
           <div className="bg-white/5 border border-white/10 p-6 rounded-xl flex flex-col items-center gap-4 hover:bg-white/10 transition group">
              <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                 <Calendar size={32} />
              </div>
              <h3 className="font-bold text-white text-lg">{t.feat2}</h3>
           </div>

           <div className="bg-white/5 border border-white/10 p-6 rounded-xl flex flex-col items-center gap-4 hover:bg-white/10 transition group">
              <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center text-yellow-400 group-hover:scale-110 transition-transform">
                 <Zap size={32} />
              </div>
              <h3 className="font-bold text-white text-lg">{t.feat3}</h3>
           </div>
        </div>

        <p className="text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
          {t.homeDesc}
        </p>
        
        <div className="max-w-md mx-auto pt-8">
            <button 
              onClick={() => setShowLogin(true)}
              className="w-full bg-brand-gold text-black font-bold text-lg py-4 rounded-xl hover:bg-white transition shadow-[0_0_20px_rgba(212,175,55,0.4)] flex items-center justify-center gap-2"
            >
              🚀 {t.startNow}
            </button>
        </div>
      </div>
    </div>
  );
};

const App = () => {
  const [lang, setLang] = useState<Language>('ar');
  const [currentUser, setCurrentUser] = useState<UserData | StaffData | null>(null);
  const [currentView, setCurrentView] = useState('home');
  const [marketingPlan, setMarketingPlan] = useState<MarketingPlan | null>(null);
  const [loading, setLoading] = useState(false);
  
  // PERSISTENCE FIX: Load from localStorage
  const [users, setUsers] = useState<UserData[]>(() => {
    try {
      const savedUsers = localStorage.getItem('b4me_users');
      return savedUsers ? JSON.parse(savedUsers) : INITIAL_USERS;
    } catch (e) {
      console.error("Failed to load users", e);
      return INITIAL_USERS;
    }
  });

  const [staffList, setStaffList] = useState<StaffData[]>(() => {
    try {
      const savedStaff = localStorage.getItem('b4me_staff');
      return savedStaff ? JSON.parse(savedStaff) : [];
    } catch (e) {
      console.error("Failed to load staff", e);
      return [];
    }
  });

  // PERSISTENCE FIX: Save to localStorage on change
  useEffect(() => {
    try {
      localStorage.setItem('b4me_users', JSON.stringify(users));
    } catch (e) {
      console.error("Failed to save users", e);
    }
  }, [users]);

  useEffect(() => {
    try {
      localStorage.setItem('b4me_staff', JSON.stringify(staffList));
    } catch (e) {
      console.error("Failed to save staff", e);
    }
  }, [staffList]);

  const t = translations[lang];

  useEffect(() => {
    document.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const handleUserLogin = (email: string, password?: string) => {
      // Check if user exists
      let user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (user) {
        if(user.password && password && user.password !== password) {
          alert(t.userNotFound);
          return;
        }

        if (user.status === 'Expired') {
          alert(t.bannedMessage);
          return;
        }
        setCurrentUser(user);
        setCurrentView('dashboard');
      } else {
        alert(t.userNotFound);
      }
  };

  const handleAdminLogin = (password: string) => {
      // Admin authentication happens in AdminLogin component
      const adminUser: StaffData = {
         id: 'ADMIN',
         email: 'admin@black4me.com',
         role: 'Admin',
         addedDate: new Date().toISOString()
      };
      setCurrentUser(adminUser);
      setCurrentView('admin');
  };

  const handleMarketingGenerate = async (input: MarketingInput) => {
    setLoading(true);
    try {
      const plan = await generateMarketingPlan(input);
      setMarketingPlan(plan);
    } catch (error) {
      alert(t.errorGen);
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    if (!currentUser) {
       if (currentView === 'admin-login') {
         return <AdminLogin onLogin={handleAdminLogin} t={t} />;
       }
       return <HomePage onLogin={handleUserLogin} t={t} lang={lang} />;
    }

    // User is logged in
    switch (currentView) {
      case 'dashboard':
        return marketingPlan ? (
          <div className="space-y-6" key={`dashboard-${lang}`}>
            <button onClick={() => setMarketingPlan(null)} className="flex items-center gap-2 text-gray-400 hover:text-white mb-4">
              <ArrowLeft size={20} /> {lang === 'ar' ? 'إنشاء خطة جديدة' : 'Create New Plan'}
            </button>
            <ResultsView plan={marketingPlan} t={t} lang={lang} />
          </div>
        ) : (
          <InputSection 
             key={`input-${lang}`}
             onGenerate={handleMarketingGenerate} 
             isLoading={loading} 
             t={t} 
             lang={lang} 
             setLang={setLang}
          />
        );
      case 'admin':
        if ((currentUser as StaffData).role !== 'Admin' && (currentUser as StaffData).role !== 'Staff') return <div>Access Denied</div>;
        return (
          <AdminDashboard 
            users={users}
            staffList={staffList}
            onAddUser={(u) => {
               const newUser: UserData = {
                 ...u,
                 id: `USR-${Math.floor(Math.random() * 10000)}`,
                 joinDate: new Date().toISOString().split('T')[0],
                 status: 'Active',
                 subscriptionEndDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
               };
               setUsers([...users, newUser]);
            }}
            onExtendUser={(id) => {
               setUsers(users.map(u => u.id === id ? {
                 ...u, 
                 status: 'Active',
                 subscriptionEndDate: new Date(new Date(u.subscriptionEndDate).getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
               } : u));
            }}
            onDeleteUser={(id) => setUsers(users.filter(u => u.id !== id))}
            onAddStaff={(email, password) => {
               const newStaff: StaffData = {
                 id: `STF-${Math.floor(Math.random() * 1000)}`,
                 email,
                 password,
                 role: 'Staff',
                 addedDate: new Date().toISOString()
               };
               setStaffList([...staffList, newStaff]);
            }}
            onRemoveStaff={(id) => setStaffList(staffList.filter(s => s.id !== id))}
            t={t}
            lang={lang}
          />
        );
      case 'profile':
        if ('role' in currentUser) return null;
        return <UserProfile user={currentUser as UserData} lang={lang} t={t} />;
      default:
        return <div>Not Found</div>;
    }
  };

  return (
    <div className={`min-h-screen bg-brand-black text-white ${lang === 'ar' ? 'font-cairo' : 'font-sans'} selection:bg-brand-gold selection:text-black overflow-x-hidden`}>
      {/* Navbar */}
      <nav className="border-b border-white/10 bg-brand-black/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 h-20 flex justify-between items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setCurrentView('home')}>
             <div className="w-10 h-10 bg-gradient-to-tr from-brand-gold to-yellow-200 rounded-lg flex items-center justify-center text-black font-bold text-xl shadow-[0_0_15px_rgba(212,175,55,0.3)]">
               B4
             </div>
             <span className="font-bold text-xl tracking-tight hidden md:block">{t.brandName}</span>
          </div>

          <div className="flex items-center gap-4">
             {currentUser ? (
               <>
                 <button 
                   onClick={() => setCurrentView('dashboard')}
                   className={`p-2 rounded-lg transition ${currentView === 'dashboard' ? 'text-brand-gold bg-white/5' : 'text-gray-400 hover:text-white'}`}
                   title={t.navDashboard}
                 >
                   <LayoutDashboard size={20} />
                 </button>
                 
                 {'role' in currentUser && (
                   <button 
                     onClick={() => setCurrentView('admin')}
                     className={`p-2 rounded-lg transition ${currentView === 'admin' ? 'text-brand-gold bg-white/5' : 'text-gray-400 hover:text-white'}`}
                     title={t.navAdmin}
                   >
                     <Users size={20} />
                   </button>
                 )}

                 {!('role' in currentUser) && (
                   <button 
                     onClick={() => setCurrentView('profile')}
                     className={`p-2 rounded-lg transition ${currentView === 'profile' ? 'text-brand-gold bg-white/5' : 'text-gray-400 hover:text-white'}`}
                     title={t.navProfile}
                   >
                     <User size={20} />
                   </button>
                 )}

                 <button 
                   onClick={() => {
                     setCurrentUser(null);
                     setCurrentView('home');
                     setMarketingPlan(null);
                   }}
                   className="p-2 rounded-lg text-red-400 hover:bg-red-500/10 transition"
                   title={t.navLogout}
                 >
                   <LogOut size={20} />
                 </button>
               </>
             ) : (
               <button 
                 onClick={() => setCurrentView(currentView === 'admin-login' ? 'home' : 'admin-login')}
                 className="text-sm text-gray-500 hover:text-brand-gold transition flex items-center gap-2"
               >
                 <Lock size={14} />
                 {currentView === 'admin-login' ? t.navHome : t.adminLogin}
               </button>
             )}

             <div className="h-6 w-px bg-white/10 mx-2"></div>

             <button 
               onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} 
               className="flex items-center gap-1 text-sm font-bold text-gray-400 hover:text-white transition"
             >
               <Globe size={16} />
               <span>{lang === 'ar' ? 'EN' : 'عربي'}</span>
             </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 min-h-[calc(100vh-80px)]">
         {renderContent()}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8 bg-black/50">
         <div className="container mx-auto px-4 text-center">
            <p className="text-gray-500 text-sm">
               &copy; {new Date().getFullYear()} {t.brandName}. All rights reserved. {t.fromMuscat}.
            </p>
         </div>
      </footer>
    </div>
  );
};

export default App;