export enum ContentType {
  HEADLINES = 'HEADLINES',
  DESCRIPTIONS = 'DESCRIPTIONS',
  SOCIAL = 'SOCIAL',
  EMAIL = 'EMAIL',
  LIFECYCLE_EMAILS = 'LIFECYCLE_EMAILS',
  ADS = 'ADS',
  SCHEDULE = 'SCHEDULE'
}

export type Language = 'ar' | 'en';

export interface MarketingInput {
  productName: string;
  platformType: string;
  description: string;
  productLink?: string;
  discountCode?: string;
  discountValue?: string;
  language: Language;
}

export interface SocialPost {
  platform: 'Instagram' | 'TikTok' | 'Twitter' | 'LinkedIn' | 'Threads' | 'Facebook';
  content: string;
  hashtags: string[];
  visualIdea: string;
  suggestedTime: string;
}

export interface ScheduledItem extends SocialPost {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  status: 'Scheduled' | 'Published' | 'Draft';
}

export interface EmailTemplate {
  subject: string;
  preview: string;
  body: string;
  type: string;
  sendDay: number | string;
}

export interface GoogleAd {
  headline: string;
  description: string;
  keywords: string[];
}

export interface MarketingPlan {
  headlines: string[];
  productDescriptions: string[]; 
  socialPosts: SocialPost[]; 
  emailSequence: EmailTemplate[]; // Marketing emails
  lifecycleEmails: EmailTemplate[]; // System emails (Welcome, Expiry, etc)
  googleAds: GoogleAd[];
  canvaIdeas: string[];
}

// Admin & Dashboard Types
export interface UserData {
  id: string;
  name: string;
  email: string;
  password?: string; // Added password for authentication
  country: string;
  phone?: string;
  joinDate: string;
  plan: 'Trial' | 'Monthly' | 'Yearly';
  price: string; // Amount paid or 'Free'
  status: 'Active' | 'Expiring Soon' | 'Expired';
  subscriptionEndDate: string; // ISO Date string YYYY-MM-DD
}

export interface StaffData {
  id: string;
  email: string;
  password?: string;
  role: 'Admin' | 'Staff';
  addedDate: string;
}

export interface GenerationStatus {
  loading: boolean;
  error: string | null;
  success: boolean;
}