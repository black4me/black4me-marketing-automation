import { GoogleGenAI, Type, Schema } from "@google/genai";
import { MarketingPlan, MarketingInput } from "../types";

const genAI = new GoogleGenAI({ apiKey: process.env.API_KEY });

const marketingSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    headlines: {
      type: Type.ARRAY,
      items: { type: Type.STRING }
    },
    productDescriptions: {
      type: Type.ARRAY,
      items: { type: Type.STRING }
    },
    socialPosts: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          platform: { type: Type.STRING, enum: ["Instagram", "TikTok", "Twitter", "LinkedIn", "Threads", "Facebook"] },
          content: { type: Type.STRING },
          hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
          visualIdea: { type: Type.STRING },
          suggestedTime: { type: Type.STRING }
        },
        required: ["platform", "content", "hashtags", "visualIdea", "suggestedTime"]
      }
    },
    emailSequence: {
      type: Type.ARRAY,
      description: "Sales/Marketing Campaign Emails",
      items: {
        type: Type.OBJECT,
        properties: {
          subject: { type: Type.STRING },
          preview: { type: Type.STRING },
          body: { type: Type.STRING },
          type: { type: Type.STRING },
          sendDay: { type: Type.NUMBER }
        },
        required: ["subject", "preview", "body", "type", "sendDay"]
      }
    },
    lifecycleEmails: {
      type: Type.ARRAY,
      description: "System Emails: Welcome, Invoice, Expiry Warning (1 week), Expiry Warning (3 days), Thank You",
      items: {
        type: Type.OBJECT,
        properties: {
          subject: { type: Type.STRING },
          preview: { type: Type.STRING },
          body: { type: Type.STRING },
          type: { type: Type.STRING }, // e.g., "Welcome", "Invoice", "Expiry 7 Days", "Expiry 3 Days"
          sendDay: { type: Type.STRING } // e.g., "Immediate", "Day 0", "Day 23"
        },
        required: ["subject", "preview", "body", "type", "sendDay"]
      }
    },
    googleAds: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          headline: { type: Type.STRING },
          description: { type: Type.STRING },
          keywords: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["headline", "description", "keywords"]
      }
    },
    canvaIdeas: {
      type: Type.ARRAY,
      items: { type: Type.STRING }
    }
  },
  required: ["headlines", "productDescriptions", "socialPosts", "emailSequence", "lifecycleEmails", "googleAds", "canvaIdeas"]
};

export const generateMarketingPlan = async (input: MarketingInput): Promise<MarketingPlan> => {
  const model = "gemini-2.5-flash";

  const langInstruction = input.language === 'en' 
    ? "Output everything in English. Tone: Professional, persuasive." 
    : "Output everything in Arabic (mix of Modern Standard and Khaleeji for social media). Tone: Professional, enthusiastic.";

  const prompt = `
    You are BLACK4ME, an elite marketing strategist.
    
    Target Audience: GCC Market (Saudi Arabia, UAE, Oman, Qatar, Kuwait, Bahrain).
    Language: ${langInstruction}
    
    Product Details:
    - Name: ${input.productName}
    - Type: ${input.platformType}
    - Description: ${input.description}
    - Link: ${input.productLink || "N/A"}
    - Discount: ${input.discountCode ? `Code: ${input.discountCode} (${input.discountValue || ""})` : "None"}
    
    TASKS:
    1. Generate 10 catchy Headlines.
    2. Generate 5 Product Descriptions (PAS, AIDA frameworks).
    3. Generate 20 Social Media Posts (Twitter/X, Instagram, LinkedIn, Facebook, Threads). Include emojis.
    4. Generate a 7-Email Sales Sequence.
    5. Generate 5 SYSTEM/LIFECYCLE EMAILS specifically:
       - Email 1: Welcome + Login Details + Payment Confirmation (Invoice).
       - Email 2: Thank You for Subscribing.
       - Email 3: Warning: Subscription expires in 1 week (Reminder).
       - Email 4: Warning: Subscription expires in 3 days (Urgent).
       - Email 5: Retention Offer (Renew now for bonus).
    6. Generate 5 Google Ads.
    7. Generate detailed visual descriptions for images.
  `;

  try {
    const result = await genAI.models.generateContent({
      model: model,
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: marketingSchema,
        temperature: 0.7,
      },
    });

    const responseText = result.text;
    if (!responseText) {
      throw new Error("No response from AI");
    }

    return JSON.parse(responseText) as MarketingPlan;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};