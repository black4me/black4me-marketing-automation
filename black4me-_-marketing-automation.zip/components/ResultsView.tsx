import React, { useState, useEffect } from 'react';
import { MarketingPlan, ContentType, ScheduledItem, SocialPost, Language } from '../types';
import { 
  Type, 
  FileText, 
  Mail, 
  Share2, 
  Calendar, 
  Copy,
  Download,
  Search,
  CheckCircle,
  Clock,
  Bell,
  Link as LinkIcon,
  Send,
  Image as ImageIcon,
  Table,
  Edit3,
  Trash2,
  Save,
  AlertTriangle,
  FileSpreadsheet,
  Printer
} from 'lucide-react';

interface ResultsViewProps {
  plan: MarketingPlan;
  t: any;
  lang: Language;
}

const ResultsView: React.FC<ResultsViewProps> = ({ plan, t, lang }) => {
  const [activeTab, setActiveTab] = useState<ContentType>(ContentType.SOCIAL);
  const [copiedIndex, setCopiedIndex] = useState<string | null>(null);
  const [connectedAccounts, setConnectedAccounts] = useState<string[]>([]);
  
  // State for editable posts before scheduling
  const [draftPosts, setDraftPosts] = useState<ScheduledItem[]>([]);
  
  // State for the "Excel Sheet" view (The Schedule)
  const [scheduledItems, setScheduledItems] = useState<ScheduledItem[]>([]);

  // Initialize drafts from plan
  useEffect(() => {
    if (plan.socialPosts) {
      const initialDrafts: ScheduledItem[] = plan.socialPosts.map((post, idx) => {
        // Default date: Tomorrow
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        return {
          ...post,
          id: `post-${idx}`,
          date: tomorrow.toISOString().split('T')[0],
          time: '10:00', // Default time
          status: 'Draft'
        };
      });
      setDraftPosts(initialDrafts);
    }
  }, [plan]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(id);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const toggleAccount = (platform: string) => {
    if (connectedAccounts.includes(platform)) {
      setConnectedAccounts(prev => prev.filter(p => p !== platform));
    } else {
      setConnectedAccounts(prev => [...prev, platform]);
    }
  };

  // Move drafts to schedule
  const handleScheduleAll = () => {
    if (connectedAccounts.length === 0) {
      alert(t.alertNoPlatform || "⚠️ تنبيه: يرجى ربط حساب منصة واحدة على الأقل قبل الجدولة.");
      return;
    }

    const postsToSchedule = draftPosts.filter(p => connectedAccounts.includes(p.platform));
    
    if (postsToSchedule.length === 0) {
        alert(t.alertNoPosts || "⚠️ لا توجد منشورات تتطابق مع المنصات المتصلة.");
        return;
    }

    const newScheduled = postsToSchedule.map(p => ({...p, status: 'Scheduled' as const}));
    
    // Add to schedule avoiding duplicates based on ID
    setScheduledItems(prev => {
        const existingIds = new Set(prev.map(i => i.id));
        const uniqueNew = newScheduled.filter(i => !existingIds.has(i.id));
        return [...prev, ...uniqueNew];
    });

    // Remove from drafts
    setDraftPosts(prev => prev.filter(p => !connectedAccounts.includes(p.platform)));

    const alertMsg = (t.alertSchedule || "✅ تمت جدولة {count} منشور بنجاح!").replace('{count}', postsToSchedule.length);
    alert(alertMsg);
    setActiveTab(ContentType.SCHEDULE);
  };

  const handleUpdateDraft = (id: string, field: 'date' | 'time' | 'content', value: string) => {
    setDraftPosts(prev => prev.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const handleDeleteScheduleItem = (id: string) => {
      if(window.confirm(t.confirmDelete || "هل أنت متأكد من حذف هذا المنشور من الجدول؟")) {
          setScheduledItems(prev => prev.filter(item => item.id !== id));
      }
  };

  const handlePublishNow = (id: string) => {
      setScheduledItems(prev => prev.map(item => item.id === id ? { ...item, status: 'Published' } : item));
      alert(t.publishedSuccess || "تم النشر بنجاح على المنصة المرتبطة! 🚀");
  };

  // --- Export Functions ---
  
  const handleDownloadExcel = () => {
    if (scheduledItems.length === 0) {
        alert(t.scheduleEmpty || "الجدول فارغ");
        return;
    }

    // CSV Header
    let csvContent = "data:text/csv;charset=utf-8,\uFEFF"; // BOM for Arabic support
    csvContent += `${t.thPlatform},${t.thDateTime},${t.thContent},${t.thStatus}\n`;

    // Rows
    scheduledItems.forEach(item => {
        const row = [
            item.platform,
            `${item.date} ${item.time}`,
            `"${item.content.replace(/"/g, '""')}"`, // Escape quotes
            item.status
        ].join(",");
        csvContent += row + "\n";
    });

    // Download
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "marketing_schedule.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintPDF = () => {
      window.print();
  };

  const TabButton = ({ type, icon: Icon, label }: { type: ContentType; icon: any; label: string }) => (
    <button
      onClick={() => setActiveTab(type)}
      className={`flex items-center space-x-2 space-x-reverse px-4 py-3 rounded-lg transition-all duration-200 whitespace-nowrap ${
        activeTab === type 
          ? 'bg-brand-gold text-black font-bold shadow-lg shadow-amber-500/20' 
          : 'bg-brand-surface text-gray-400 hover:text-white hover:bg-white/5 border border-white/5'
      }`}
    >
      <Icon size={18} />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="w-full space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 print:p-0 print:bg-white print:text-black">
      {/* Header - Hidden in Print */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-white/10 pb-6 print:hidden">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight">{t.dashboardTitle}</h2>
          <p className="text-brand-gold mt-1 text-sm">{t.dashboardSubtitle}</p>
        </div>
        <div className="flex flex-wrap gap-3 mt-4 md:mt-0">
          <button 
            onClick={handlePrintPDF}
            className="flex items-center gap-2 bg-brand-surface border border-white/10 text-white px-4 py-2 rounded hover:bg-white/10 transition text-sm"
          >
             <Printer size={16} />
             <span>{t.printBtn}</span>
          </button>
          <button 
            onClick={handleDownloadExcel}
            className="flex items-center gap-2 bg-green-900/30 border border-green-500/30 text-green-400 px-4 py-2 rounded hover:bg-green-900/50 transition text-sm"
          >
             <FileSpreadsheet size={16} />
             <span>{t.excelBtn}</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs - Hidden in Print */}
      <div className="flex gap-2 md:gap-4 pb-2 overflow-x-auto no-scrollbar print:hidden">
        <TabButton type={ContentType.SOCIAL} icon={Share2} label={t.tabDrafts} />
        <TabButton type={ContentType.SCHEDULE} icon={Calendar} label={t.tabSchedule} />
        <TabButton type={ContentType.LIFECYCLE_EMAILS} icon={Bell} label={t.tabSystem} />
        <TabButton type={ContentType.EMAIL} icon={Mail} label={t.tabSales} />
        <TabButton type={ContentType.HEADLINES} icon={Type} label={t.tabHeadlines} />
        <TabButton type={ContentType.DESCRIPTIONS} icon={FileText} label={t.tabDescriptions} />
        <TabButton type={ContentType.ADS} icon={Search} label={t.tabAds} />
      </div>

      {/* Content Area */}
      <div className="min-h-[600px] bg-brand-surface border border-white/5 rounded-2xl p-6 md:p-8 shadow-2xl print:shadow-none print:border-none print:bg-white print:text-black">
        
        {/* SOCIAL DRAFTS TAB */}
        {activeTab === ContentType.SOCIAL && (
          <div className="space-y-8">
            {/* Account Connection & Scheduling Controls */}
            <div className="bg-brand-black p-6 rounded-xl border border-white/10 flex flex-col gap-6 shadow-inner">
               <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                   <div>
                     <h3 className="font-bold text-white text-lg flex items-center gap-2">
                        <LinkIcon size={20} className="text-brand-gold"/>
                        {t.connectTitle}
                     </h3>
                     <p className="text-sm text-gray-400 mt-1">{t.connectDesc}</p>
                   </div>
                   
                   <div className="flex flex-wrap justify-center gap-3">
                     {['Twitter', 'Facebook', 'LinkedIn', 'Threads', 'Instagram', 'TikTok'].map(platform => (
                       <button 
                         key={platform}
                         onClick={() => toggleAccount(platform)}
                         className={`relative px-4 py-2 rounded-lg text-sm font-bold border-2 transition-all flex items-center gap-2 ${
                           connectedAccounts.includes(platform) 
                             ? 'bg-brand-gold/10 text-brand-gold border-brand-gold shadow-[0_0_10px_rgba(212,175,55,0.2)]' 
                             : 'bg-transparent text-gray-500 border-gray-700 hover:border-gray-500 grayscale'
                         }`}
                       >
                         {connectedAccounts.includes(platform) && (
                            <div className="absolute -top-2 -right-2 bg-green-500 text-black rounded-full p-0.5">
                                <CheckCircle size={12} />
                            </div>
                         )}
                         {platform}
                       </button>
                     ))}
                   </div>
               </div>
               
               <div className="h-px bg-white/10 w-full"></div>

               <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-sm">
                        {(t.selectedPlatforms || "").replace('{count}', connectedAccounts.length)}
                    </span>
                    <button 
                        onClick={handleScheduleAll}
                        className={`px-8 py-3 rounded-lg font-bold flex items-center gap-2 transition-all shadow-lg ${
                        connectedAccounts.length > 0
                            ? 'bg-blue-600 text-white hover:bg-blue-500 hover:scale-105 shadow-blue-900/20' 
                            : 'bg-gray-700 text-gray-400 cursor-not-allowed'
                        }`}
                    >
                        <Calendar size={18}/>
                        {t.moveToSchedule}
                    </button>
               </div>
            </div>

            {/* Editable Drafts List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {draftPosts.length === 0 ? (
                  <div className="col-span-2 text-center py-20 text-gray-500">
                      <CheckCircle size={48} className="mx-auto mb-4 text-green-500 opacity-50"/>
                      <p>{t.scheduleEmptyDesc}</p>
                  </div>
              ) : (
                  draftPosts.map((post) => (
                    <div key={post.id} className="bg-brand-black border border-white/10 rounded-xl flex flex-col group hover:border-brand-gold/30 transition-colors">
                    <div className="p-4 border-b border-white/5 flex justify-between items-center bg-white/5">
                        <div className="flex items-center gap-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                            post.platform === 'Instagram' ? 'bg-pink-900/50 text-pink-400' :
                            post.platform === 'TikTok' ? 'bg-cyan-900/50 text-cyan-400' :
                            post.platform === 'LinkedIn' ? 'bg-blue-900/50 text-blue-400' :
                            'bg-gray-800 text-gray-300'
                        }`}>
                            {post.platform}
                        </span>
                        <span className="text-xs text-yellow-500 font-medium bg-yellow-900/20 px-2 py-0.5 rounded border border-yellow-700/30">
                            {t.draftLabel}
                        </span>
                        </div>
                    </div>
                    
                    <div className="p-5 flex-grow space-y-4">
                        {/* Editor Controls */}
                        <div className="grid grid-cols-2 gap-3 mb-4">
                            <div>
                                <label className="text-[10px] text-gray-500 block mb-1">{t.pubDate}</label>
                                <input 
                                    type="date" 
                                    value={post.date}
                                    onChange={(e) => handleUpdateDraft(post.id, 'date', e.target.value)}
                                    className="w-full bg-brand-surface border border-white/10 rounded px-2 py-1 text-sm text-white focus:border-brand-gold outline-none"
                                />
                            </div>
                            <div>
                                <label className="text-[10px] text-gray-500 block mb-1">{t.pubTime}</label>
                                <input 
                                    type="time" 
                                    value={post.time}
                                    onChange={(e) => handleUpdateDraft(post.id, 'time', e.target.value)}
                                    className="w-full bg-brand-surface border border-white/10 rounded px-2 py-1 text-sm text-white focus:border-brand-gold outline-none"
                                />
                            </div>
                        </div>

                        <textarea 
                            value={post.content}
                            onChange={(e) => handleUpdateDraft(post.id, 'content', e.target.value)}
                            className="w-full bg-brand-surface border border-white/5 rounded p-3 text-white text-sm min-h-[100px] focus:border-brand-gold/50 outline-none resize-none leading-relaxed"
                        />

                        <div className="bg-brand-surface p-3 rounded text-sm text-gray-400 border border-dashed border-gray-700 flex gap-3 items-start">
                        <ImageIcon size={16} className="text-gray-600 mt-1 shrink-0"/>
                        <div>
                            <span className="text-brand-gold font-bold block mb-1 text-xs">{t.visualIdea}</span>
                            {post.visualIdea}
                        </div>
                        </div>
                    </div>
                    </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* SCHEDULE TAB (EXCEL VIEW) */}
        {activeTab === ContentType.SCHEDULE && (
            <div className="space-y-6">
                 <div className="bg-green-900/20 border border-green-500/30 p-4 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <FileSpreadsheet className="text-green-400" size={24} />
                        <div>
                            <h4 className="font-bold text-white">{t.scheduleTitle}</h4>
                            <p className="text-sm text-gray-300">{t.scheduleDesc}</p>
                        </div>
                    </div>
                    <button 
                        onClick={handleDownloadExcel} 
                        className="bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded font-bold text-sm flex items-center gap-2"
                    >
                        <Download size={16}/> {t.excelBtn}
                    </button>
                 </div>

                 {scheduledItems.length === 0 ? (
                     <div className="text-center py-20 bg-brand-black rounded-xl border border-white/10 border-dashed">
                         <Calendar size={48} className="mx-auto mb-4 text-gray-600"/>
                         <h3 className="text-xl font-bold text-white">{t.scheduleEmpty}</h3>
                         <p className="text-gray-500 mt-2">{t.scheduleEmptyDesc}</p>
                     </div>
                 ) : (
                    <div className="overflow-x-auto rounded-xl border border-white/10">
                        <table className="w-full text-sm bg-brand-black">
                            <thead className="bg-white/5 text-gray-400 font-medium">
                                <tr>
                                    <th className={`p-4 ${lang === 'ar' ? 'text-right' : 'text-left'}`}>{t.thPlatform}</th>
                                    <th className={`p-4 ${lang === 'ar' ? 'text-right' : 'text-left'}`}>{t.thDateTime}</th>
                                    <th className={`p-4 w-1/2 ${lang === 'ar' ? 'text-right' : 'text-left'}`}>{t.thContent}</th>
                                    <th className={`p-4 ${lang === 'ar' ? 'text-right' : 'text-left'}`}>{t.thStatus}</th>
                                    <th className={`p-4 ${lang === 'ar' ? 'text-right' : 'text-left'}`}>{t.thActions}</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5">
                                {scheduledItems.map((item) => (
                                    <tr key={item.id} className="hover:bg-white/5 transition group">
                                        <td className="p-4 align-top">
                                            <span className="font-bold text-white block">{item.platform}</span>
                                        </td>
                                        <td className="p-4 align-top">
                                            <div className="flex flex-col gap-1 text-gray-300">
                                                <span className="flex items-center gap-1"><Calendar size={12}/> {item.date}</span>
                                                <span className="flex items-center gap-1"><Clock size={12}/> {item.time}</span>
                                            </div>
                                        </td>
                                        <td className="p-4 align-top">
                                            <p className="text-gray-300 line-clamp-3 hover:line-clamp-none transition-all cursor-pointer" title={item.content}>
                                                {item.content}
                                            </p>
                                        </td>
                                        <td className="p-4 align-top">
                                            <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-bold ${
                                                item.status === 'Published' 
                                                ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                                                : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                            }`}>
                                                {item.status === 'Published' ? <CheckCircle size={10}/> : <Clock size={10}/>}
                                                {item.status === 'Published' ? t.statusPublished : t.statusScheduled}
                                            </span>
                                        </td>
                                        <td className="p-4 align-top">
                                            <div className="flex items-center gap-2 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity">
                                                {item.status !== 'Published' && (
                                                    <button 
                                                        onClick={() => handlePublishNow(item.id)}
                                                        title={t.statusPublished}
                                                        className="p-2 bg-green-600 hover:bg-green-500 text-white rounded transition"
                                                    >
                                                        <Send size={14} />
                                                    </button>
                                                )}
                                                <button 
                                                    onClick={() => handleDeleteScheduleItem(item.id)}
                                                    title="Delete"
                                                    className="p-2 bg-red-900/50 hover:bg-red-600 text-red-200 hover:text-white rounded transition"
                                                >
                                                    <Trash2 size={14} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                 )}
            </div>
        )}

        {/* LIFECYCLE EMAILS (SYSTEM) */}
        {activeTab === ContentType.LIFECYCLE_EMAILS && (
           <div className="space-y-6">
             <div className="bg-blue-900/20 border border-blue-500/30 p-4 rounded-lg flex items-start gap-3">
                <Bell className="text-blue-400 mt-1" size={20} />
                <div>
                   <h4 className="font-bold text-white">{t.sysEmailTitle}</h4>
                   <p className="text-sm text-gray-300">{t.sysEmailDesc}</p>
                </div>
             </div>

             {plan.lifecycleEmails.map((email, idx) => (
               <div key={idx} className="bg-brand-black border border-white/10 rounded-xl overflow-hidden">
                 <div className="bg-white/5 p-4 flex justify-between items-center border-b border-white/5">
                   <div className="flex items-center gap-4">
                     <span className={`text-black text-xs font-bold px-3 py-1 rounded-full ${
                       email.type.includes('Warning') ? 'bg-red-500 text-white' : 
                       email.type.includes('Welcome') ? 'bg-green-500 text-black' : 'bg-brand-gold'
                     }`}>
                       {email.type}
                     </span>
                     <span className="text-gray-300 font-semibold text-sm">{t.sendTime} {email.sendDay}</span>
                   </div>
                   <button onClick={() => copyToClipboard(email.body, `life-${idx}`)} className="text-gray-500 hover:text-brand-gold">
                      {copiedIndex === `life-${idx}` ? <CheckCircle size={18} className="text-green-500"/> : <Copy size={18} />}
                   </button>
                 </div>
                 <div className="p-6 space-y-4">
                   <div className="space-y-1">
                     <span className="text-gray-500 text-xs uppercase">{t.subject}</span>
                     <p className="text-white font-bold">{email.subject}</p>
                   </div>
                   <div className="bg-white/5 p-4 rounded text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">
                     {email.body}
                   </div>
                 </div>
               </div>
             ))}
           </div>
        )}

        {/* SALES EMAILS */}
        {activeTab === ContentType.EMAIL && (
          <div className="space-y-6">
            {plan.emailSequence.map((email, idx) => (
              <div key={idx} className="bg-brand-black border border-white/10 rounded-xl overflow-hidden">
                <div className="bg-white/5 p-4 flex justify-between items-center border-b border-white/5">
                  <div className="flex items-center gap-4">
                    <span className="bg-gray-700 text-white text-xs font-bold px-3 py-1 rounded-full">
                      {t.day || "Day"} {email.sendDay}
                    </span>
                    <span className="text-gray-300 font-semibold text-sm">{email.type}</span>
                  </div>
                  <button onClick={() => copyToClipboard(email.body, `email-${idx}`)} className="text-gray-500 hover:text-brand-gold">
                     {copiedIndex === `email-${idx}` ? <CheckCircle size={18} className="text-green-500"/> : <Copy size={18} />}
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-brand-surface p-3 rounded border border-white/5">
                      <span className="text-gray-500 text-xs uppercase block mb-1">{t.subject}</span>
                      <p className="text-white font-medium">{email.subject}</p>
                    </div>
                    <div className="bg-brand-surface p-3 rounded border border-white/5">
                      <span className="text-gray-500 text-xs uppercase block mb-1">{t.preview}</span>
                      <p className="text-gray-400">{email.preview}</p>
                    </div>
                  </div>
                  <div className="pt-2">
                    <p className="text-gray-300 text-sm leading-loose whitespace-pre-wrap font-light border-r-2 border-brand-gold/30 pr-4">
                      {email.body}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* HEADLINES */}
        {activeTab === ContentType.HEADLINES && (
          <div className="grid gap-3">
             {plan.headlines.map((headline, idx) => (
               <div key={idx} className="group flex justify-between items-center bg-brand-black p-4 rounded-lg border border-white/5 hover:border-brand-gold/50 transition">
                  <span className="text-white text-lg font-medium">
                    <span className="text-brand-gold mx-3 font-bold">#{idx + 1}</span> 
                    {headline}
                  </span>
                  <button 
                    onClick={() => copyToClipboard(headline, `hl-${idx}`)} 
                    className="text-gray-500 hover:text-brand-gold p-2"
                  >
                    {copiedIndex === `hl-${idx}` ? <CheckCircle size={20} className="text-green-500"/> : <Copy size={20} />}
                  </button>
               </div>
             ))}
          </div>
        )}

        {/* DESCRIPTIONS */}
        {activeTab === ContentType.DESCRIPTIONS && (
          <div className="space-y-6">
            {plan.productDescriptions.map((desc, idx) => (
              <div key={idx} className="bg-brand-black p-6 rounded-xl border border-white/10 relative">
                 <div className="absolute top-4 left-4">
                    <button 
                      onClick={() => copyToClipboard(desc, `desc-${idx}`)} 
                      className="text-gray-500 hover:text-brand-gold"
                    >
                      {copiedIndex === `desc-${idx}` ? <CheckCircle size={20} className="text-green-500"/> : <Copy size={20} />}
                    </button>
                 </div>
                 <p className="text-gray-200 leading-relaxed whitespace-pre-line text-lg">
                   {desc}
                 </p>
              </div>
            ))}
          </div>
        )}

        {/* ADS */}
        {activeTab === ContentType.ADS && (
          <div className="grid gap-6">
            {plan.googleAds.map((ad, idx) => (
              <div key={idx} className="bg-white p-4 rounded-lg border border-gray-200 max-w-2xl">
                 <div className="flex items-center gap-2 mb-1">
                   <span className="text-black font-bold">{t.adLabel}</span>
                   <span className="text-gray-500 text-sm">www.yoursite.com</span>
                 </div>
                 <h4 className="text-[#1a0dab] text-xl hover:underline cursor-pointer mb-1 font-medium">{ad.headline}</h4>
                 <p className="text-[#4d5156] text-sm">{ad.description}</p>
                 <div className="mt-4 pt-3 border-t border-gray-100">
                    <div className="flex flex-wrap gap-2">
                      {ad.keywords.map((kw, i) => (
                        <span key={i} className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs">{kw}</span>
                      ))}
                    </div>
                 </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
};

export default ResultsView;