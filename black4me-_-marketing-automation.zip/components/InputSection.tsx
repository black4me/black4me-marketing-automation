import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowLeft, Link as LinkIcon, Tag, Store, Globe } from 'lucide-react';
import { MarketingInput, Language } from '../types';

interface InputSectionProps {
  onGenerate: (data: MarketingInput) => void;
  isLoading: boolean;
  t: any;
  lang: Language;
  setLang: (lang: Language) => void;
}

const InputSection: React.FC<InputSectionProps> = ({ onGenerate, isLoading, t, lang, setLang }) => {
  const [formData, setFormData] = useState<MarketingInput>({
    productName: '',
    platformType: 'Store',
    description: '',
    productLink: '',
    discountCode: '',
    discountValue: '',
    language: lang
  });

  // Sync formData language when prop changes (e.g. from Navbar)
  useEffect(() => {
    setFormData(prev => ({ ...prev, language: lang }));
  }, [lang]);

  const handleChange = (field: keyof MarketingInput, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.productName && formData.description) {
      onGenerate(formData);
    }
  };

  return (
    <div className="max-w-4xl mx-auto w-full">
      <form onSubmit={handleSubmit} className="bg-brand-surface border border-white/5 rounded-2xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
        
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-brand-gold/5 rounded-full blur-3xl -translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>
        
        <div className="relative z-10 space-y-8">
          <div className="flex justify-between items-center border-b border-white/5 pb-6">
            <div>
               <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">{t.inputTitle}</h2>
               <p className="text-gray-400 text-sm">{t.inputSubtitle}</p>
            </div>
            
            <div className="bg-brand-black p-1 rounded-lg border border-white/10 flex">
               <button
                 type="button"
                 onClick={() => { handleChange('language', 'ar'); setLang('ar'); }}
                 className={`px-4 py-2 rounded text-sm font-bold transition-all ${lang === 'ar' ? 'bg-brand-gold text-black' : 'text-gray-400 hover:text-white'}`}
               >
                 العربية
               </button>
               <button
                 type="button"
                 onClick={() => { handleChange('language', 'en'); setLang('en'); }}
                 className={`px-4 py-2 rounded text-sm font-bold transition-all ${lang === 'en' ? 'bg-brand-gold text-black' : 'text-gray-400 hover:text-white'}`}
               >
                 English
               </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Column 1 */}
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-brand-gold flex items-center gap-2">
                  <Store size={16}/> {t.prodName}
                </label>
                <input
                  type="text"
                  value={formData.productName}
                  onChange={(e) => handleChange('productName', e.target.value)}
                  placeholder={t.prodNamePlace}
                  className="w-full bg-brand-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-300">{t.platformType}</label>
                <select
                  value={formData.platformType}
                  onChange={(e) => handleChange('platformType', e.target.value)}
                  className="w-full bg-brand-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-gold transition-all appearance-none cursor-pointer"
                >
                  <option value="Store">{t.pt_store}</option>
                  <option value="Landing Page">{t.pt_landing}</option>
                  <option value="Blog">{t.pt_blog}</option>
                  <option value="Social Account">{t.pt_social}</option>
                  <option value="Service">{t.pt_service}</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-300 flex items-center gap-2">
                  <LinkIcon size={16}/> {t.prodLink}
                </label>
                <input
                  type="url"
                  value={formData.productLink}
                  onChange={(e) => handleChange('productLink', e.target.value)}
                  placeholder="https://example.com"
                  className="w-full bg-brand-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-brand-gold transition-all"
                />
              </div>
            </div>

            {/* Column 2 */}
            <div className="space-y-6">
              <div className="space-y-2">
                 <label className="text-sm font-bold text-brand-gold">{t.prodDesc}</label>
                 <textarea
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  placeholder={t.prodDescPlace}
                  className="w-full h-[135px] bg-brand-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all resize-none leading-relaxed"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-300 flex items-center gap-2">
                    <Tag size={16}/> {t.discountCode}
                  </label>
                  <input
                    type="text"
                    value={formData.discountCode}
                    onChange={(e) => handleChange('discountCode', e.target.value)}
                    placeholder="OMAN2024"
                    className="w-full bg-brand-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-brand-gold transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-300">{t.discountVal}</label>
                  <input
                    type="text"
                    value={formData.discountValue}
                    onChange={(e) => handleChange('discountValue', e.target.value)}
                    placeholder="15%"
                    className="w-full bg-brand-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-brand-gold transition-all"
                  />
                </div>
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading || !formData.productName || !formData.description}
            className={`w-full mt-8 group relative flex items-center justify-center space-x-2 space-x-reverse py-4 rounded-lg font-bold text-lg transition-all duration-300 ${
              isLoading 
                ? 'bg-gray-800 cursor-not-allowed text-gray-500' 
                : 'bg-brand-gold hover:bg-white hover:text-black text-black shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_30px_rgba(212,175,55,0.5)]'
            }`}
          >
            {isLoading ? (
              <span className="flex items-center">
                <svg className="animate-spin ml-3 h-5 w-5 text-gray-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {t.genBtn}
              </span>
            ) : (
              <>
                <Sparkles size={20} className="group-hover:text-brand-gold transition-colors duration-300" />
                <span>{t.launchBtn}</span>
                <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default InputSection;